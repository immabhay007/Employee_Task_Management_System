import { useEffect, useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const AddTask = () => {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [allProjects,setAllProjects] = useState([]);
  const [projectName ,setProjectName] = useState();

  let navigate = useNavigate();

  useEffect(() => {
    const getAllProject = async () => {
      const allProject = await retrieveAllProject();
      if (allProject) {
        setAllProjects(allProject);
      }
    };

    getAllProject();
  }, []);

  const retrieveAllProject = async () => {
    var manager = JSON.parse(sessionStorage.getItem("active-manager"));
        var id = manager.id;
        console.log(id);
    const response = await axios.get(
      "http://localhost:8080/api/project/fetch/"+id
    );
    console.log(response.data);
    return response.data;
  };

  const saveTask = (e) => {
    e.preventDefault();
    console.log(projectName);
    var manager = JSON.parse(sessionStorage.getItem("active-manager"));
        var managerId = manager.id;
        console.log(managerId);
    let data = { name, description , projectName , managerId};

    fetch("http://localhost:8080/api/task/add", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    }).then((result) => {
      result.json().then((res) => {
        console.log(res);

        console.log(res.responseMessage);
           
              navigate("/home");
              toast.success(res.responseMessage, {
                position: "top-center",
                autoClose: 1000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
              });
      });
      
    });
  };

  return (
    <div>
      <div className="mt-2 d-flex aligns-items-center justify-content-center">
        <div
          className="card form-card border-color custom-bg"
          style={{ width: "25rem" }}
        >
          <div className="card-header bg-color text-center custom-bg-text">
            <h5 className="card-title">Add Task</h5>
          </div>
          <div className="card-body text-color">
            <form onSubmit={saveTask}> 
            <div className="mb-3 text-color">
                <label htmlFor="projectName" className="form-label">
                  <b> Project Name</b>
                </label>
                <select
                   onChange={(e) => {
                    setProjectName(e.target.value);
                  }}
                  className="form-control"
                  id="projectName"
                  name="projectName"
                >
                  <option value="0">Select Project</option>

                  {allProjects.map((project) => {
                    return (
                      <option value={project.name}> {project.name} </option>
                    );
                  })}

                </select>
              </div>
              <div className="mb-3">
                <label htmlFor="name" className="form-label">
                  <b>Task Name</b>
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="name"
                  placeholder="enter name.."
                  onChange={(e) => {
                    setName(e.target.value);
                  }}
                  value={name}
                />
              </div>
              <div className="mb-3">
                <label htmlFor="description" className="form-label">
                  <b>Task Description</b>
                </label>
                <textarea
                  className="form-control"
                  id="description"
                  rows="3"
                  placeholder="enter description.."
                  onChange={(e) => {
                    setDescription(e.target.value);
                  }}
                  value={description}
                />
              </div>

              
              <input
                type="submit"
                className="btn bg-color custom-bg-text"
                value="Add Task"
              />

              <ToastContainer />
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddTask;
