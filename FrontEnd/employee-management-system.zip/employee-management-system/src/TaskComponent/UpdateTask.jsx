import axios from "axios";
import { useEffect, useState } from "react";
import { json, useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";

const UpadteTask  = () =>{

    const [allTasks,setAllTasks] = useState([]);

    const[allStatus,setAllStatus] = useState([]);

    const[taskName,setTaskName] = useState("");

    const[updatedStatus,setUpdatedStatus] = useState("");

    // const[managerName,setManagerName] = useState("");

    // let [user1 , setUser1] =  useState(0);
    let navigate = useNavigate();
    
    // const handleUserInput = (e) => {
    //   setUser({ ...user, [e.target.name]: e.target.value });
    // };

    useEffect(()=>{
        const getAllTasks = async () => {
            const allTasks = await retrieveAllTask();
            if(allTasks){
                setAllTasks(allTasks);
            }
        }

        getAllTasks();
    },[]);

    useEffect(()=>{
      const getAllStatus = async () => {
          const allStatus = await retrieveAllStatus();
          if(allStatus){
            setAllStatus(allStatus.projectStatus);
          }
      }

      getAllStatus();
  },[]);

    const retrieveAllTask = async () => {
        var employee = JSON.parse(sessionStorage.getItem("active-employee"));
        var id = employee.id;
        console.log(id);
        const response = await axios.get(
            "http://localhost:8080/api/task/get/"+id
        );
        console.log(response.data);
        return response.data;
    };

    const retrieveAllStatus = async () => {
      const response = await axios.get(
          "http://localhost:8080/api/task/taskStatus"
      );
      console.log(response.data);
      return response.data;
  };
    
    // useEffect(() => {
    // const getAllProject = async () => {
    //     const allProject = await retrieveAllProject();
    //     if (allProject) {
    //       setAllProjects(allProject);
    //     }
    //   };
  
    //   getAllProject();
    // }, []);
  
    // const retrieveAllProject = async () => {
    //   const response = await axios.get(
    //     "http://localhost:8080/api/task/fetch"
    //   );
    //   console.log(response.data);
    //   return response.data;
    // };
    console.log(taskName,updatedStatus);

    const updateTask = (e) => {
        e.preventDefault();
        console.log(taskName);
        console.log(updatedStatus);
        console.log(sessionStorage.getItem("active-employee"));
        // let user = sessionStorage.getItem("active-manager");
        console.log(typeof(sessionStorage.getItem("active-employee")));
        console.log(JSON.parse(sessionStorage.getItem("active-employee")));
        console.log(JSON.parse(sessionStorage.getItem("active-employee")));
        var employee = JSON.parse(sessionStorage.getItem("active-employee"));
        var id = employee.id;
        // setUser1(id);
        // user1 = user.id;
        // setManagerName({...user1});
        // const handleUserInput = (e) => {
        //     setUser({ ...user, [e.target.name]: e.target.value });
        //   };
        // let user1 = user.id;
        console.log(updatedStatus);
        let data = { taskName, updatedStatus };
        console.log(data);
    
        fetch("http://localhost:8080/api/task/updateTask", {
          method: "PUT",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        }).then((result) => {
          result.json().then((res) => {
            console.log(res);
    
            console.log(res.responseMessage);
               
                  navigate("/home");
                  toast.success(res.responseMessage, {
                    position: "top-center",
                    autoClose: 1000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                  });
          });
          
        });
      };

    return(
        <div>
      <div className="mt-2 d-flex aligns-items-center justify-content-center ms-2 me-2 mb-2">
        <div
          className="card form-card border-color text-color custom-bg"
          style={{ width: "25rem" }}
        >
          <div className="card-header bg-color custom-bg-text text-center">
            <h5 className="card-title">Update Task</h5>
          </div>
          <div className="card-body">
            <form onSubmit={updateTask}>
              
              <div className="mb-3 text-color">
                <label htmlFor="taskName" className="form-label">
                  <b> Task Name</b>
                </label>
                <select
                   onChange={(e) => {
                    setTaskName(e.target.value);
                  }}
                  className="form-control"
                  id="taskName"
                  name="taskName"
                >
                  <option value="0">Select Task</option>

                  {allTasks.map((task) => {
                    return (
                      <option value={task.name}> {task.name} </option>
                    );
                  })}

                </select>
              </div>
             
              <div className="mb-3 text-color">
                <label htmlFor="updatedStatus" className="form-label">
                  <b> Update Status</b>
                </label>
                <select
                  onChange={(e) => {
                    setUpdatedStatus(e.target.value);
                  }}
                  className="form-control"
                  id="updatedStatus"
                  name="updatedStatus"
                >
                  <option value="0">Update Status</option>

                  {allStatus.map((status) => {
                    return (
                      <option value={status}> {status} </option>
                    );
                  })}

                </select>
              </div>
                
              <input
                type="submit"
                className="btn bg-color custom-bg-text"
                value="Update Task"
              />
              <ToastContainer />
            </form>
          </div>
        </div>
      </div>
    </div>
    );    
}

export default UpadteTask;
