import { useState, useEffect } from "react";
import axios from "axios";
import React from "react";

const ViewAllTasks = () => {
  const [allTasks, setAllTasks] = useState([]);

  const [TaskName, setTaskName] = useState("");
  const [taskId, setTaskId] = useState("");

  useEffect(() => {
    const getAllTasks = async () => {
      const allTasks = await retrieveAllTasks();
      if (allTasks) {
        setAllTasks(allTasks);
      }
    };

    getAllTasks();
  }, []);

  const retrieveAllTasks = async () => {
    var manager = JSON.parse(sessionStorage.getItem("active-manager"));
    var id = manager.id;
    console.log(id);
  const response = await axios.get(
        "http://localhost:8080/api/task/fetch/"+id
    );
    console.log(response.data);
    return response.data;
  };

  // const getTaskByName = async () => {
  //   const allTasks = await retrieveTaskByName();
  //   if (allTasks) {
  //     setAllTasks(allTasks);
  //   }
  // };

  // const retrieveTaskByName = async () => {
  //   const response = await axios.get(
  //     "http://localhost:8080/api/project/search?projectName="+projectName
  //   );
  //   console.log(response.data);
  //   return response.data;
  // };

  // const searchTaskbyName = (e) => {
  //   getTaskByName();
  //   setTaskName("");
  //   e.preventDefault();
  // };

  // const getTaskById = async () => {
  //   const allTasks = await retrieveTaskById();
  //   if (allTasks) {
  //     setAllTasks(allTasks);
  //   }
  // };

  // const retrieveTaskById = async () => {
  //   const response = await axios.get(
  //     "http://localhost:8080/api/task/search/id?taskId="+taskId
  //   );
  //   console.log(response.data);
  //   return response.data;
  // };

  // const searchTaskbyId = (e) => {
  //   getTaskById();
  //   setTaskId("");
  //   e.preventDefault();
  // };

  return (
    <div className="mt-3">
      <div
        className="card form-card ms-2 me-2 mb-5 custom-bg border-color "
        style={{
          height: "45rem",
        }}
      >
        <div className="card-header custom-bg-text text-center bg-color">
          <h2>All Tasks</h2>
        </div>
        <div
          className="card-body"
          style={{
            overflowY: "auto",
          }}
        >

       {/* <div className="row g-3">
       <div class="col-auto">
        <form class="row g-3">
            <div class="col-auto">
              <input
                type="text"
                class="form-control"
                id="inputPassword2"
                placeholder="Enter Task Name..."
                onChange={(e) => setTaskName(e.target.value)}
                value={TaskName}
              />
            </div>
            <div class="col-auto">
              <button
                type="submit"
                class="btn bg-color custom-bg-text mb-3"
                onClick={searchTaskbyName}
              >
                Search
              </button>
            </div>
          </form>
</div>
<div class="col-auto">
          <form class="row g-3">
            <div class="col-auto">
              <input
                type="number"
                class="form-control"
                id="inputPassword2"
                placeholder="Enter Task Id..."
                onChange={(e) => setTaskId(e.target.value)}
                value={taskId}
                required
              />
            </div>
            <div class="col-auto">
              <button
                type="submit"
                class="btn bg-color custom-bg-text mb-3"
                onClick={searchTaskbyId}
              >
                Search
              </button>
            </div>
          </form>
          </div>
          </div> */}
          <div className="table-responsive">
            <table className="table table-hover text-color text-center">
              <thead className="table-bordered border-color bg-color custom-bg-text">
                <tr>
                  <th scope="col">Task Name</th>
                  <th scope="col">Task Description</th>
                  <th scope="col">Assigned Manager</th>
                  <th scope="col">Assigned Employee</th>
                  <th scope="col">Task Status</th>
                  <th scope="col">Project id</th>
                </tr>
              </thead>
              <tbody>
                {allTasks.map((task) => {
                  return (
                    <tr>
                      <td>
                        <b>{task.name}</b>
                      </td>
                      
                      <td>
                        <b>{task.description}</b>
                      </td>
                      <td>
                        <b>{task.assignedToManager}</b>
                      </td>
                      <td>
                        <b>{task.assignedToEmployee}</b>
                      </td>
                      
                      <td>
                        <b>{task.projectStatus}</b>
                      </td>
                      <td>
                        <b>{task.projectId}</b>
                      </td> 
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ViewAllTasks;
