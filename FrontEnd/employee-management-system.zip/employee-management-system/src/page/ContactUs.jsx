
const ContactUs = () => {
  return (
    <div className="text-color ms-5 me-5 mr-5 mt-3">
     <b>
      Welcome to our Employee Task Management system mini project, designed to 
      simplify the task management process for businesses of all sizes.
        <br />
      
        At our company, we understand that managing tasks and projects can be a challenging task,
       especially when dealing with a large number of employees and various tasks.
        That's why we created our Employee Task Management system to help streamline
         the process and ensure that tasks are completed on time.

      Our team consists of experienced developers who are passionate about 
      creating efficient and effective solutions to complex problems.
       We are committed to providing our clients with a user-friendly
       platform that is easy to navigate and customize according to their specific needs.
    
      Our Employee Task Management system allows managers to assign tasks 
      to employees, track their progress, and set deadlines to ensure that 
      projects are completed on time. Our platform also allows employees 
      to view their assigned tasks, update their progress, and communicate with their team members.

      We are dedicated to providing exceptional customer service and 
      support to ensure that our clients are satisfied with our product. 
      Our team is available to answer any questions and provide assistance as needed.

      Thank you for choosing our Employee Task Management system. 
      We look forward to working with you and helping you streamline
      your task management process.
      </b>
    </div>
  );
};

export default ContactUs;
