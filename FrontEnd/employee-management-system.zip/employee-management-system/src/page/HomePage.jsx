import Carousel from "./Carousel";
import axios from "axios";
import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";

const HomePage = () => {

  return (
    <div className="container-fluid mb-2">
      <Carousel />
      {/* <div className="mt-2 mb-5">
        <div className="row">
          <div className="col-md-2">
            <GetAllLocations />
          </div>
          <div className="col-md-8">
          <div className="row row-cols-1 row-cols-md-3 g-3">
              {hotels.map((hotel) => {
                return <HotelCard item={hotel} />;
              })}
            </div>
          </div>
          <div className="col-md-2">
            <GetAllFacility />
          </div>
          
        </div>
      </div> */}
    </div>
  );
};

export default HomePage;
