import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";

const AssignProject  = () =>{

    const [allProjects,setAllProjects] = useState([]);

    const[allManagers,setAllManagers] = useState([]);

    const[projectName,setProjectName] = useState("");

    const[managerName,setManagerName] = useState("");

    let navigate = useNavigate();
    
    // const handleUserInput = (e) => {
    //   setUser({ ...user, [e.target.name]: e.target.value });
    // };

    useEffect(()=>{
        const getAllProjects = async () => {
            const allProjects = await retrieveAllProject();
            if(allProjects){
                setAllProjects(allProjects);
            }
        }

        getAllProjects();
    },[]);

    useEffect(()=>{
      const getAllManagers = async () => {
          const allManagers = await retrieveAllManager();
          if(allManagers){
              setAllManagers(allManagers);
          }
      }

      getAllManagers();
  },[]);

    const retrieveAllProject = async () => {
        const response = await axios.get(
            "http://localhost:8080/api/project/fetch"
        );
        console.log(response.data);
        return response.data;
    };

    const retrieveAllManager = async () => {
      const response = await axios.get(
          "http://localhost:8080/api/user/manager/all"
      );
      console.log(response.data);
      return response.data;
  };
    
    // useEffect(() => {
    // const getAllProject = async () => {
    //     const allProject = await retrieveAllProject();
    //     if (allProject) {
    //       setAllProjects(allProject);
    //     }
    //   };
  
    //   getAllProject();
    // }, []);
  
    // const retrieveAllProject = async () => {
    //   const response = await axios.get(
    //     "http://localhost:8080/api/task/fetch"
    //   );
    //   console.log(response.data);
    //   return response.data;
    // };
    console.log(projectName,managerName);

    const updateProject = (e) => {
        e.preventDefault();
        console.log(managerName);
        let data = { projectName, managerName };
        console.log(data);
    
        fetch("http://localhost:8080/api/project/assignProject", {
          method: "PUT",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        }).then((result) => {
          result.json().then((res) => {
            console.log(res);
    
            console.log(res.responseMessage);
               
                  navigate("/home");
                  toast.success(res.responseMessage, {
                    position: "top-center",
                    autoClose: 1000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                  });
          });
          
        });
      };

    return(
        <div>
      <div className="mt-2 d-flex aligns-items-center justify-content-center ms-2 me-2 mb-2">
        <div
          className="card form-card border-color text-color custom-bg"
          style={{ width: "25rem" }}
        >
          <div className="card-header bg-color custom-bg-text text-center">
            <h5 className="card-title">Assign Project</h5>
          </div>
          <div className="card-body">
            <form onSubmit={updateProject}>
              
              <div className="mb-3 text-color">
                <label htmlFor="projectName" className="form-label">
                  <b> Project Name</b>
                </label>
                <select
                   onChange={(e) => {
                    setProjectName(e.target.value);
                  }}
                  className="form-control"
                  id="projectName"
                  name="projectName"
                >
                  <option value="0">Select Project</option>

                  {allProjects.map((project) => {
                    return (
                      <option value={project.name}> {project.name} </option>
                    );
                  })}

                </select>
              </div>
             
              <div className="mb-3 text-color">
                <label htmlFor="managerName" className="form-label">
                  <b> Manager Name</b>
                </label>
                <select
                  onChange={(e) => {
                    setManagerName(e.target.value);
                  }}
                  className="form-control"
                  id="projectName"
                  name="managerName"
                >
                  <option value="0">Assign Manager</option>

                  {allManagers.map((manager) => {
                    return (
                      <option value={manager.firstName}> {manager.firstName} </option>
                    );
                  })}

                </select>
              </div>
                
              <input
                type="submit"
                className="btn bg-color custom-bg-text"
                value="Assign Project"
              />
              <ToastContainer />
            </form>
          </div>
        </div>
      </div>
    </div>
    );    
}

export default AssignProject;
