import { Link, useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const ManagerHeader = () => {
  let navigate = useNavigate();

  const user = JSON.parse(sessionStorage.getItem("active-manager"));
  console.log(user);

  const managerLogout = () => {
    toast.success("logged out!!!", {
      position: "top-center",
      autoClose: 1500,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
    sessionStorage.removeItem("active-manager");
    window.location.reload(true);
    navigate("/");
  };

  return (
    <ul class="navbar-nav ms-auto mb-2 mb-lg-0 me-5">

      <li class="nav-item">
        <Link
          to="/user/manager/project/all"
          class="nav-link active"
          aria-current="page"
        >
          <b className="text-color">All Projects</b>
        </Link>
      </li>

      {/* /user/manager/updateProject */}

      <li class="nav-item">
        <Link
          to="/user/manager/updateProject"
          class="nav-link active"
          aria-current="page"
        >
          <b className="text-color">Update Project</b>
        </Link>
      </li>

      <li class="nav-item">
        <Link
          to="/user/employee/task/all"
          class="nav-link active"
          aria-current="page"
        >
          <b className="text-color">View All Tasks</b>
        </Link>
      </li>
      
      <li className="nav-item">
        <Link to="/user/employee/register" className="nav-link active" aria-current="page">
          <b className="text-color">Register Employee</b>
        </Link>
      </li>

      <li class="nav-item">
        <Link
          to="/user/employee/all"
          class="nav-link active"
          aria-current="page"
        >
          <b className="text-color">View All Employees</b>
        </Link>
      </li>

      <li class="nav-item">
        <Link
          to="/user/manager/task/addTask"
          class="nav-link active"
          aria-current="page"
        >
          <b className="text-color">Add Task</b>
        </Link>
      </li>

      <li class="nav-item">
        <Link
          to="user/manager/assignTask"
          class="nav-link active"
          aria-current="page"
        >
          <b className="text-color">Assign Task</b>
        </Link>
      </li>

      <li class="nav-item">
        <Link
          to="user/manager/updateProfile"
          class="nav-link active"
          aria-current="page"
        >
          <b className="text-color">Update Profile</b>
        </Link>
      </li>

      <li class="nav-item">
        <Link
          to=""
          class="nav-link active"
          aria-current="page"
          onClick={managerLogout}
        >
          <b className="text-color">Logout</b>
        </Link>
        <ToastContainer />
      </li>
    </ul>
  );
};

export default ManagerHeader;
