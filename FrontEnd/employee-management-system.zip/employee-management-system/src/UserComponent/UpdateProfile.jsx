import { useState, useEffect } from "react";
import "react-toastify/dist/ReactToastify.css";
import { ToastContainer, toast } from "react-toastify";
import axios from "axios";

const UpdateProfile = () => {
  
  const [user, setUser] = useState({
    firstName: "",
    lastName: "",
    contact: "",
    street: "",
    city: "",
    pincode: "",
    role: "",
    age:"",
    sex:""
  });

  if(document.URL.indexOf("admin") != -1) {
    user.role = "admin";
  } else if (document.URL.indexOf("manager") != -1) {
    user.role = "manager";
  } else if (document.URL.indexOf("employee") != -1) {
    user.role = "employee";
  }  

  console.log("ROLE FECTHED : "+user.role)

  const handleUserInput = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const [genders, setGenders] = useState([]);

  const retrieveAllGenders = async () => {
    const response = await axios.get("http://localhost:8080/api/user/gender");
    return response.data;
  };

  useEffect(() => {
    const getAllGenders = async () => {
      const allGenders = await retrieveAllGenders();
      if (allGenders) {
          setGenders(allGenders.genders);
      }
    };

    getAllGenders();
  }, []);


  const saveUser = (event) => {
    event.preventDefault();
    var id = 0;
    if(document.URL.indexOf("admin") != -1) {
        var admin = JSON.parse(sessionStorage.getItem("active-admin"));
        id = admin.id;
      } else if (document.URL.indexOf("manager") != -1) {
        var manager = JSON.parse(sessionStorage.getItem("active-manager"));
        id = manager.id;
      } else if (document.URL.indexOf("employee") != -1) {
        var employee = JSON.parse(sessionStorage.getItem("active-employee"));
        id = employee.id;
      }  
     
      console.log(id);
    // var manager = JSON.parse(sessionStorage.getItem("active-manager"));
    // var id = manager.id;
    // console.log(id);
    fetch("http://localhost:8080/api/user/update/"+id, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(user),
    }).then((result) => {
      
      toast.success("Profile Updated Successfully!!!", {
        position: "top-center",
        autoClose: 1000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
     
      result
        .json()
        .then((res) => {
          console.log("response", res);
        })
        .catch((error) => {
          console.log(error);
        });
    });
  };

  return (
    <div>
      <div className="mt-2 d-flex aligns-items-center justify-content-center ms-2 me-2 mb-2">
        <div
          className="card form-card border-color text-color custom-bg"
          style={{ width: "25rem" }}
        >
          <div className="card-header bg-color custom-bg-text text-center">
            <h5 className="card-title">Update Profile</h5>
          </div>
          <div className="card-body">
            <form onSubmit={saveUser}>
              
              <div className="mb-3 text-color">
                <label htmlFor="title" className="form-label">
                  <b> First Name</b>
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="firstName"
                  name="firstName"
                  onChange={handleUserInput}
                  value={user.firstName}
                />
              </div>
              <div className="mb-3 text-color">
                <label htmlFor="description" className="form-label">
                  <b>Last Name</b>
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="lastName"
                  name="lastName"
                  onChange={handleUserInput}
                  value={user.lastName}
                />
              </div>

              {/* <div className="mb-3 text-color">
                <b>
                  <label className="form-label">Email Id</label>
                </b>
                <input
                  type="email"
                  className="form-control"
                  id="emailId"
                  name="emailId"
                  onChange={handleUserInput}
                  value={user.emailId}
                />
              </div>

              <div className="mb-3 mt-1">
                <b>
                <label htmlFor="quantity" className="form-label">
                  Password
                </label>
                </b>
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  name="password"
                  onChange={handleUserInput}
                  value={user.password}
                />
              </div> */}

              <div className="mb-3 text-color">
                <label htmlFor="sex" className="form-label">
                  <b>User Gender</b>
                </label>
                <select
                  onChange={handleUserInput}
                  className="form-control"
                  name="sex"
                >
                  <option value="0">Select Gender</option>

                  {genders.map((gender) => {
                    return (
                      <option value={gender}> {gender} </option>
                    );
                  })}

                </select>
              </div>


              <div className="mb-3">
                <label htmlFor="contact" className="form-label">
                  <b>Contact No</b>
                </label>
                <input
                  type="number"
                  className="form-control"
                  id="contact"
                  name="contact"
                  onChange={handleUserInput}
                  value={user.contact}
                />
              </div>

              <div className="mb-3">
                <label htmlFor="contact" className="form-label">
                  <b>Age</b>
                </label>
                <input
                  type="number"
                  className="form-control"
                  id="age"
                  name="age"
                  onChange={handleUserInput}
                  value={user.age}
                />
              </div>

              <div className="mb-3">
                <label htmlFor="description" className="form-label">
                  <b> Street</b>
                </label>
                <textarea
                  className="form-control"
                  id="street"
                  name="street"
                  rows="3"
                  onChange={handleUserInput}
                  value={user.street}
                />
              </div>

              <div className="mb-3">
                <label htmlFor="price" className="form-label">
                  <b>City</b>
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="city"
                  name="city"
                  onChange={handleUserInput}
                  value={user.city}
                />
              </div>

              <div className="mb-3">
                <label htmlFor="pincode" className="form-label">
                  <b>Pincode</b>
                </label>
                <input
                  type="number"
                  className="form-control"
                  id="pincode"
                  name="pincode"
                  onChange={handleUserInput}
                  value={user.pincode}
                />
              </div>

              <input
                type="submit"
                className="btn bg-color custom-bg-text"
                value="Update"
              />

              <ToastContainer />
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UpdateProfile;
